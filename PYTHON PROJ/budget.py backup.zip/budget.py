#!/usr/bin/python

import time
import datetime 
import csv

## dd/mm/yyyy format
#today = (time.strftime("%m/%d/%Y"))
today = datetime.date.today()

def FileCheck(fn):
    try:
        open(fn, "rU")
        return True
    except IOError:
        return False

if(FileCheck("data.csv") == True):
    print "File Exists"
    data = csv.reader(open("data.csv", "rU"))
    num_rows = sum(1 for row in data)
    
    data = csv.reader(open("data.csv", "rU"))
    data = list(data)
   
    
    
    if(data[num_rows-1][0] == today.strftime("%Y-%m-%d")):
        print "up to date!"
    else:
        f = "%Y-%m-%d"
        last_known_date = datetime.datetime.strptime(data[num_rows-1][0], f)
        num_days_between = today - last_known_date
        print num_days_between
        new_row = [datetime.date.today(), 0, 0, 0, 0, 0, 0];
        file = csv.writer(open("data.csv","a"), delimiter=',',quoting=csv.QUOTE_ALL)
        file.writerow(new_row)

    
    
#    for row in data:
#       text = row[0]
#       print text
    

if(FileCheck("data.csv") == False):
    print "File not found. Creating..."
    data1 = ["Day/Category", "Food/Dining", "Entertainment", "General Bills", "Transportation", "Cosmetics", "Miscellaneous"];
    data2 = [datetime.date.today(), 0, 0, 0, 0, 0, 0];
    out = csv.writer(open("data.csv","w"), delimiter=',',quoting=csv.QUOTE_ALL)
    out.writerow(data1)
    out.writerow(data2)







